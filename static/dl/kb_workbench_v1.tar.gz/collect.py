#!/usr/bin/env python3
"""抖音创作者中心 · 低频采集（仅自己的账号）

⚠️ 使用边界
  - 只采集【你自己账号】的数据
  - 每小时最多 1 次（有锁文件强制）
  - 不批量爬别人、不并发、不改 UA
  - 平台条款禁止自动化抓取，风险自担；账号被风控请立刻停

用法:
  python3 collect.py --login       # 第一次：打开浏览器，你自己扫码登录，保存登录态
  python3 collect.py --collect     # 之后：用保存的登录态打开创作者中心，导出作品数据
  python3 collect.py --collect --headed   # 看着它跑（调试用）
"""
import argparse, json, pathlib, time, datetime, sys

BASE = pathlib.Path(__file__).parent
STATE = BASE / "collector" / "state.json"
LOCK = BASE / "collector" / "last_run.txt"
OUT = BASE / "collector" / "collected.json"
BASE.joinpath("collector").mkdir(exist_ok=True)

CREATOR = "https://creator.douyin.com/creator-micro/content/manage"

def need_pw():
    try:
        from playwright.sync_api import sync_playwright
        return sync_playwright
    except ImportError:
        print("缺 playwright：pip install playwright && playwright install chromium"); sys.exit(1)

def do_login():
    sync_playwright = need_pw()
    with sync_playwright() as p:
        b = p.chromium.launch(headless=False)
        ctx = b.new_context()
        pg = ctx.new_page()
        pg.goto("https://creator.douyin.com/", wait_until="domcontentloaded")
        print("\n>>> 浏览器已打开。请在窗口里扫码登录抖音。")
        print(">>> 登录完成后回到这里按回车……")
        input()
        ctx.storage_state(path=str(STATE))
        print(f"✓ 登录态已保存 → {STATE}")
        b.close()

def do_collect(headed=False):
    sync_playwright = need_pw()
    if not STATE.exists():
        print("还没有登录态，先跑 --login"); return
    # 低频锁
    if LOCK.exists():
        last = datetime.datetime.fromisoformat(LOCK.read_text().strip())
        if (datetime.datetime.now() - last).total_seconds() < 3600:
            print(f"距上次采集不足 1 小时（{last:%H:%M}），跳过。"); return

    with sync_playwright() as p:
        b = p.chromium.launch(headless=not headed)
        ctx = b.new_context(storage_state=str(STATE), viewport={"width": 1440, "height": 900})
        pg = ctx.new_page()
        pg.goto(CREATOR, wait_until="domcontentloaded")
        time.sleep(5)
        if "login" in pg.url.lower():
            print("登录态失效，重新跑 --login"); return

        # 抓表格/列表行 —— 选择器可能要按页面版本微调
        rows = pg.evaluate("""() => {
          const out = [];
          const trs = [...document.querySelectorAll('tr, .content-card, [class*=row], [class*=item]')];
          for (const tr of trs) {
            const t = (tr.innerText || '').replace(/\\s+/g,' ').trim();
            if (t.length > 20 && /\\d/.test(t)) out.push(t.slice(0, 400));
          }
          return [...new Set(out)];
        }""")
        pg.screenshot(path=str(BASE / "collector" / "last_page.png"), full_page=False)
        b.close()

    data = {"collected_at": datetime.datetime.now().isoformat(timespec="seconds"),
            "source": CREATOR, "rows": rows}
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    LOCK.write_text(datetime.datetime.now().isoformat(timespec="seconds"))
    print(f"✓ 抓到 {len(rows)} 行 → {OUT}")
    print("  截图 → collector/last_page.png（先看一眼格式对不对）")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--login", action="store_true")
    ap.add_argument("--collect", action="store_true")
    ap.add_argument("--headed", action="store_true")
    a = ap.parse_args()
    if a.login: do_login()
    elif a.collect: do_collect(a.headed)
    else: ap.print_help()
