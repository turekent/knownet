#!/usr/bin/env python3
"""抖音创作者中心导出的 CSV → 统一 data/posts.json

用法:
    python3 ingest_csv.py 作品数据.csv [--account 主号]

特点:
  - 不依赖 pandas，只用标准库
  - 中文列名模糊匹配（抖音导出的表头经常变）
  - 重复导入按「作品ID/标题+发布日期」去重，旧的覆盖新的
"""
import csv, json, re, sys, pathlib, datetime

BASE = pathlib.Path(__file__).parent
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)
STORE = DATA / "posts.json"

# 列名 → 字段（按优先级；命中任意一个即可）
MAP = {
    "id":        ["作品id", "视频id", "item_id", "id"],
    "title":     ["作品标题", "视频标题", "标题", "title", "作品名称"],
    "publish":   ["发布时间", "发布日期", "publish_time", "时间"],
    "play":      ["播放量", "播放次数", "播放", "play", "vv"],
    "finish":    ["完播率", "完播", "finish_rate"],
    "like":      ["点赞量", "点赞数", "点赞", "like"],
    "comment":   ["评论量", "评论数", "评论", "comment"],
    "share":     ["分享量", "分享数", "分享", "share"],
    "collect":   ["收藏量", "收藏数", "收藏", "collect"],
    "follow":    ["涨粉", "新增粉丝", "粉丝增量", "follow"],
    "duration":  ["时长", "视频时长", "duration"],
    "cover_click": ["封面点击率", "点击率", "ctr"],
    "avg_watch": ["平均播放时长", "平均观看时长", "avg_watch"],
}

def norm(s):
    return re.sub(r"[\s_\-（）()%％:：]", "", str(s)).lower()

def pick(row, keys):
    nrow = {norm(k): v for k, v in row.items()}
    for k in keys:
        nk = norm(k)
        for rk, rv in nrow.items():
            if nk == rk or nk in rk:
                v = (rv or "").strip()
                if v != "":
                    return v
    return ""

def to_int(v):
    if not v: return None
    s = re.sub(r"[^\d.]", "", str(v))
    if not s: return None
    try:
        f = float(s)
        return int(f)
    except ValueError:
        return None

def to_rate(v):
    """完播率/点击率 → 0~1 的小数"""
    if not v: return None
    s = str(v).replace("％", "%").strip()
    m = re.search(r"([\d.]+)\s*%", s)
    if m:
        return round(float(m.group(1)) / 100, 4)
    f = to_int(s)
    if f is None: return None
    return round(f / 100, 4) if f > 1 else float(f)

def main():
    if len(sys.argv) < 2:
        print("用法: python3 ingest_csv.py 作品数据.csv [--account 主号]"); sys.exit(1)
    path = pathlib.Path(sys.argv[1])
    account = "默认"
    if "--account" in sys.argv:
        account = sys.argv[sys.argv.index("--account") + 1]

    raw = path.read_bytes()
    for enc in ("utf-8-sig", "gb18030", "utf-8"):
        try:
            text = raw.decode(enc); break
        except UnicodeDecodeError:
            continue
    rows = list(csv.DictReader(text.splitlines()))
    if not rows:
        print("CSV 没读到数据行"); sys.exit(1)

    print(f"读到 {len(rows)} 行，表头: {list(rows[0].keys())[:14]}")

    store = json.loads(STORE.read_text(encoding="utf-8")) if STORE.exists() else {"posts": []}
    by_key = {(p.get("account"), p.get("id") or p.get("title")): i for i, p in enumerate(store["posts"])}

    added = updated = 0
    for r in rows:
        rec = {
            "account": account,
            "id": pick(r, MAP["id"]),
            "title": pick(r, MAP["title"]),
            "publish": pick(r, MAP["publish"]),
            "play": to_int(pick(r, MAP["play"])),
            "finish_rate": to_rate(pick(r, MAP["finish"])),
            "like": to_int(pick(r, MAP["like"])),
            "comment": to_int(pick(r, MAP["comment"])),
            "share": to_int(pick(r, MAP["share"])),
            "collect": to_int(pick(r, MAP["collect"])),
            "follow": to_int(pick(r, MAP["follow"])),
            "duration": pick(r, MAP["duration"]),
            "cover_click": to_rate(pick(r, MAP["cover_click"])),
            "avg_watch": pick(r, MAP["avg_watch"]),
            "imported_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        if not rec["title"] and not rec["id"]:
            continue
        k = (account, rec["id"] or rec["title"])
        if k in by_key:
            store["posts"][by_key[k]] = rec; updated += 1
        else:
            store["posts"].append(rec); by_key[k] = len(store["posts"]) - 1; added += 1

    store["updated"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    STORE.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"新增 {added} 条，更新 {updated} 条，共 {len(store['posts'])} 条 → {STORE}")

if __name__ == "__main__":
    main()
