#!/usr/bin/env python3
"""data/posts.json → 运营分析报告 reports/YYYY-MM-DD.html
用法: python3 report.py [--top 10]
"""
import json, pathlib, datetime, statistics, html, argparse

BASE = pathlib.Path(__file__).parent
STORE = BASE / "data" / "posts.json"
OUT = BASE / "reports"

def pct(x): return "—" if x is None else f"{x*100:.1f}%"
def num(x):
    if x is None: return "—"
    return f"{x/10000:.1f}万" if x >= 10000 else str(x)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--top", type=int, default=10)
    args = ap.parse_args()
    if not STORE.exists():
        print("还没有数据，先跑 ingest_csv.py"); return
    posts = json.loads(STORE.read_text(encoding="utf-8"))["posts"]
    if not posts: print("数据为空"); return

    fins = [p["finish_rate"] for p in posts if p.get("finish_rate") is not None]
    avg_fin = statistics.mean(fins) if fins else None
    plays = [p["play"] for p in posts if p.get("play")]
    med_play = statistics.median(plays) if plays else None

    issues = []
    for p in posts:
        f = p.get("finish_rate")
        if f is not None and avg_fin and f < avg_fin * 0.7:
            issues.append(("完播率低", p, f"完播率 {pct(f)}，低于账号均值 {pct(avg_fin)} 的 70%。建议：找 3~5 条同类爆款，逐条拆开头 3 秒和节奏。"))
        cc = p.get("cover_click")
        if cc is not None and cc < 0.05:
            issues.append(("封面点击低", p, f"封面点击率 {pct(cc)}。建议：封面换成一个具体物件，别用纯文字。"))
        if p.get("play") and med_play and p["play"] < med_play * 0.3:
            issues.append(("播放异常低", p, f"播放 {num(p['play'])}，低于中位数 {num(med_play)} 的 30%。先分辨是选题问题还是发布时间问题。"))

    rows = []
    for p in sorted(posts, key=lambda x: -(x.get("play") or 0))[: args.top]:
        rows.append("<tr>"
            f"<td>{html.escape(str(p.get('publish') or '—'))}</td>"
            f"<td class='t'>{html.escape((p.get('title') or '')[:40])}</td>"
            f"<td class='n'>{num(p.get('play'))}</td>"
            f"<td class='n'>{pct(p.get('finish_rate'))}</td>"
            f"<td class='n'>{num(p.get('like'))}</td>"
            f"<td class='n'>{num(p.get('comment'))}</td>"
            f"<td class='n'>{num(p.get('follow'))}</td></tr>")

    issue_html = "".join(
        f"<div class='card'><div class='k'>{html.escape(k)}</div>"
        f"<div class='tt'>{html.escape((p.get('title') or '')[:50])}</div>"
        f"<div class='ad'>{html.escape(a)}</div></div>" for k, p, a in issues[:12])

    page = f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>运营分析 · {datetime.date.today()}</title>
<style>
:root{{--navy:#1E3A5F;--line:#e3e8ef;--muted:#6b7a90;--bg:#F5F7FA}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:#1a2332;font:15px/1.7 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif}}
header{{background:var(--navy);color:#fff;padding:26px 20px}}.wrap{{max-width:1000px;margin:0 auto}}
h1{{margin:0;font-size:21px}}.sub{{opacity:.8;font-size:13.5px;margin-top:6px}}
main{{padding:22px 20px 60px}}
.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px}}
.kpi{{background:#fff;border-radius:12px;padding:16px;box-shadow:0 1px 3px rgba(16,24,40,.06)}}
.kpi .v{{font-size:24px;font-weight:700;color:var(--navy);font-variant-numeric:tabular-nums}}
.kpi .l{{font-size:12.5px;color:var(--muted);margin-top:2px}}
table{{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(16,24,40,.06);margin-bottom:24px}}
th,td{{padding:11px 12px;text-align:left;border-bottom:1px solid var(--line);font-size:14px}}
th{{background:#f7f9fc;color:var(--muted);font-size:12.5px;font-weight:600}}
td.n{{text-align:right;font-variant-numeric:tabular-nums}}td.t{{max-width:320px}}
.card{{background:#fff;border-radius:12px;padding:16px;margin-bottom:10px;border-left:4px solid #d97706}}
.card .k{{font-size:12.5px;color:#b45309;font-weight:600}}
.card .tt{{font-weight:600;margin:4px 0 6px}}.card .ad{{color:#3a4a60;font-size:14px}}
h2{{font-size:17px;margin:26px 0 12px;color:var(--navy)}}
footer{{text-align:center;color:var(--muted);font-size:12.5px;padding:0 20px 40px}}
</style></head><body>
<header><div class="wrap"><h1>运营分析报告</h1>
<div class="sub">生成于 {datetime.datetime.now():%Y-%m-%d %H:%M}　·　数据 {len(posts)} 条</div></div></header>
<main><div class="wrap">
<div class="kpis">
<div class="kpi"><div class="v">{len(posts)}</div><div class="l">作品数</div></div>
<div class="kpi"><div class="v">{num(sum(p.get('play') or 0 for p in posts))}</div><div class="l">总播放</div></div>
<div class="kpi"><div class="v">{num(med_play)}</div><div class="l">播放中位数</div></div>
<div class="kpi"><div class="v">{pct(avg_fin)}</div><div class="l">平均完播率</div></div>
</div>
<h2>作品表现（按播放排序）</h2>
<table><thead><tr><th>发布</th><th>标题</th><th>播放</th><th>完播率</th><th>点赞</th><th>评论</th><th>涨粉</th></tr></thead>
<tbody>{''.join(rows) or '<tr><td colspan=7>暂无</td></tr>'}</tbody></table>
<h2>需要关注的 {len(issues)} 条</h2>
{issue_html or '<p style="color:#6b7a90">没有触发规则的问题 ✓</p>'}
</div></main><footer>workbench · 本地生成，不上传任何数据</footer></body></html>"""

    OUT.mkdir(exist_ok=True)
    f = OUT / f"{datetime.date.today()}.html"
    f.write_text(page, encoding="utf-8")
    print(f"报告 → {f}")
    print(f"作品 {len(posts)} 条 / 平均完播 {pct(avg_fin)} / 触发规则 {len(issues)} 条")

if __name__ == "__main__":
    main()
